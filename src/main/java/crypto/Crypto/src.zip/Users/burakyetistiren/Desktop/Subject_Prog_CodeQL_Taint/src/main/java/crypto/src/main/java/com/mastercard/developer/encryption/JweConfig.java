package com.mastercard.developer.encryption;

public class JweConfig extends EncryptionConfig {
}
